# Atlas Principles

1. People before technology.
2. Context before data.
3. Calm before complexity.
4. Understanding before action.
5. Quality before speed.

Zusätzliche Prinzipien:
- Atlas macht nicht abhängig.
- Atlas lernt immer.
- Atlas entfernt unnötige Komplexität.
