# ATLAS SEEDS

- Kompass -> Vision
- Weg statt Ziel
- Leitplanken statt Mauern
- Orientierung statt Kontrolle
- Mensch × KI
- Atlas Book lebt ewig
- Chronicler als erster Bewohner
- Werkstätten für Fähigkeiten
- Ziele statt Technologien
- Nichts von Wert darf verloren gehen
