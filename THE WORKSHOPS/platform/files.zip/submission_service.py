"""
Atlas Submission Service — clientunabhängige Einreichungslogik.

Schnittstelle:
    submit(yaml_path) -> SubmissionResult

Kein CLI-Parsing, keine print-Ausgaben, keine Git-Befehle direkt.
Gibt strukturierte Ergebnisse zurück, die jeder Client verwerten kann.
"""

import os
import re
import subprocess
import shutil
import yaml
from dataclasses import dataclass
from typing import Optional


SUBMISSIONS_DIR = "THE WORKSHOPS/platform/submissions"
VALIDATOR = "THE WORKSHOPS/platform/validator/validator.py"
GIT_HASH_RE = re.compile(r"^[0-9a-f]{7,40}$")


@dataclass
class SubmissionResult:
    success: bool
    submission_id: Optional[str] = None
    branch_name: Optional[str] = None
    commit_sha: Optional[str] = None
    pull_request_url: Optional[str] = None
    error: Optional[str] = None


def _run(cmd, capture=True):
    r = subprocess.run(cmd, shell=True, text=True, capture_output=capture)
    return r


def _validate(yaml_path) -> Optional[str]:
    """Strukturableitbare Prüfung. Gibt None zurück wenn OK, sonst Fehlermeldung."""
    r = _run(f'python "{VALIDATOR}" "{yaml_path}"')
    if r.returncode != 0:
        return r.stdout.strip() or "Strukturelle Validierung fehlgeschlagen."
    return None


def _load(yaml_path):
    with open(yaml_path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def _derive_branch(submission_id) -> Optional[str]:
    branch = f"submission/{submission_id}"
    r = _run(f'git branch --list "{branch}"')
    if r.stdout.strip():
        return None  # Branch existiert bereits
    return branch


def _derive_pr_title(data) -> str:
    sid = data["submission"]["id"]
    claim = str(data["candidate"]["claim"]).strip().replace("\n", " ")
    short = claim[:72] + "..." if len(claim) > 72 else claim
    return f"[{sid}] {short}"


def _derive_pr_body(data) -> str:
    sub = data["submission"]
    cand = data["candidate"]
    return (
        "## Atlas Submission\n\n"
        f"- Submission-ID: `{sub['id']}`\n"
        f"- Typ: `{sub['type']}`\n"
        f"- Aktion: `{sub['action']}`\n"
        f"- Vorgeschlagene Referenz: `{cand['proposed_ref']}`\n"
        f"- Basis-Commit: `{sub['base_commit']}`\n\n"
        "Diese Pull Request wurde automatisch aus der Submission erzeugt.\n\n"
        "Die GitHub Action prüft ausschließlich strukturableitbare Anforderungen.\n"
        "Ein erfolgreicher Lauf ist kein semantisches Urteil."
    )


def submit(yaml_path: str) -> SubmissionResult:
    """
    Reicht eine Submission ein.
    
    Args:
        yaml_path: Pfad zur Submission-YAML-Datei
        
    Returns:
        SubmissionResult mit Ergebnis und Metadaten
    """
    if not os.path.exists(yaml_path):
        return SubmissionResult(success=False, error=f"Datei nicht gefunden: {yaml_path}")

    # 1. Strukturableitbare Validierung
    error = _validate(yaml_path)
    if error:
        return SubmissionResult(success=False, error=error)

    # 2. Daten laden
    data = _load(yaml_path)
    sid = data["submission"]["id"]

    # 3. Branch ableiten
    branch = _derive_branch(sid)
    if branch is None:
        return SubmissionResult(
            success=False,
            submission_id=sid,
            error=f"Branch 'submission/{sid}' existiert bereits. Doppelte ID oder unvollständiger Vorgang."
        )

    # 4. Branch erstellen
    r = _run(f'git checkout -b "{branch}"')
    if r.returncode != 0:
        return SubmissionResult(success=False, submission_id=sid, error=f"Branch-Fehler: {r.stderr}")

    try:
        # 5. Datei ablegen
        target = f"{SUBMISSIONS_DIR}/{sid}.yaml"
        os.makedirs(SUBMISSIONS_DIR, exist_ok=True)
        shutil.copy(yaml_path, target)

        # 6. Commit
        _run(f'git add "{target}"')
        r = _run(f'git commit -m "[{sid}] Add submission"')
        if r.returncode != 0:
            return SubmissionResult(success=False, submission_id=sid, error=f"Commit-Fehler: {r.stderr}")

        # 7. Commit-SHA lesen
        sha_r = _run("git rev-parse HEAD")
        commit_sha = sha_r.stdout.strip() if sha_r.returncode == 0 else None

        # 8. Push
        r = _run(f'git push -u origin "{branch}"')
        if r.returncode != 0:
            return SubmissionResult(success=False, submission_id=sid, error=f"Push-Fehler: {r.stderr}")

        # 9. PR erstellen
        title = _derive_pr_title(data)
        body = _derive_pr_body(data)
        r = _run(f'gh pr create --title "{title}" --body "{body}" --base master')
        pr_url = r.stdout.strip() if r.returncode == 0 else None
        if r.returncode != 0:
            return SubmissionResult(
                success=False, submission_id=sid, branch_name=branch,
                commit_sha=commit_sha, error=f"PR-Fehler: {r.stderr}"
            )

        return SubmissionResult(
            success=True,
            submission_id=sid,
            branch_name=branch,
            commit_sha=commit_sha,
            pull_request_url=pr_url
        )

    finally:
        _run("git checkout master")
