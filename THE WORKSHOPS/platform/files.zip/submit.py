"""
Atlas Submit CLI — lokaler Client für den Submission-Service.

Verwendung:
    python submit.py <submission.yaml> [--dry-run]
"""

import sys
from submission_service import submit, _validate, _load, _derive_branch, _derive_pr_title


def main():
    dry_run = "--dry-run" in sys.argv
    args = [a for a in sys.argv[1:] if not a.startswith("--")]

    if len(args) != 1:
        print("Verwendung: python submit.py <submission.yaml> [--dry-run]")
        sys.exit(1)

    path = args[0]

    if dry_run:
        print("=== Strukturableitbare Prüfung ===")
        error = _validate(path)
        if error:
            print(error)
            sys.exit(1)
        data = _load(path)
        sid = data["submission"]["id"]
        branch = f"submission/{sid}"
        title = _derive_pr_title(data)
        print(f"\n=== Einreichung (dry-run) ===")
        print(f"Submission-ID : {sid}")
        print(f"Branch        : {branch}")
        print(f"PR-Titel      : {title}")
        print("\n[dry-run] Kein Branch, kein Commit, kein PR erstellt.")
        return

    result = submit(path)

    if result.success:
        print(f"✓ Submission eingereicht")
        print(f"  ID     : {result.submission_id}")
        print(f"  Branch : {result.branch_name}")
        print(f"  Commit : {result.commit_sha}")
        print(f"  PR     : {result.pull_request_url}")
    else:
        print(f"✗ Fehler: {result.error}")
        sys.exit(1)


if __name__ == "__main__":
    main()
